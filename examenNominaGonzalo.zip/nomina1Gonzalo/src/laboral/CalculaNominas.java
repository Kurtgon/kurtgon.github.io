/**
 * @author Gonzalo
 * @version 0.0.1
 * 
 */

package laboral;

import java.util.ArrayList;

public class CalculaNominas {
		

	public static void main(String[] args) {
				
		ArrayList <Empleado> listaEmpleados=new ArrayList<Empleado>();
		
		
		//listaEmpleados.add(new Empleado("James Cosling","32000032G",'M',4,7); 
		//listaEmpleados.add(new Empleado("Ada Lovelace", "32000031R",'F');

	}
	
	
	

}
