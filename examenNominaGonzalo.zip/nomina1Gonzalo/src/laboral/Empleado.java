package laboral;

public class Empleado extends Persona {
	
	private int categoria=1;
	public int anyos=0;
		
	public Empleado(int categoria, int anyos, String nombre, String dni, char sexo) {
		
		super (nombre, dni, sexo);
		this.categoria=categoria;
		this.anyos=anyos;
		this.nombre=nombre;
		this.dni=dni;
		this.sexo=sexo;
		
	}
	
	public Empleado(String nombre, String dni, char sexo) {
		super(nombre, dni, sexo);
		this.nombre=nombre;
		this.dni=dni;
		this.sexo=sexo;
	}

	
	public void setCategoria(int categoria) {
		
		this.categoria=categoria;
		
	}
	
	public int getCategoria() {
		
		return categoria;
	}
	
	public void incrAnyo() {
		
		anyos+=+1;
		anyos++;
	}
	
	public String imprime() {
		
		return "Los datos del Empleado: " + nombre + " con dni: " + dni + "sexo: " + sexo + 
				" con categoría " + categoria + ", y años trabajado " + anyos;
	}
}
