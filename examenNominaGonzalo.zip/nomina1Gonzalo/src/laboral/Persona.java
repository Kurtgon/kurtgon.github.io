package laboral;

public class Persona {
	
	public String nombre;
	public String dni;
	public char sexo;
	
	public Persona (String nombre, String dni, char sexo) {
		
		
		this.nombre = nombre;
		this.dni = dni;
		this.sexo = sexo;
	}
	
	public Persona (String nombre, char sexo) {
		
		this.nombre = nombre;
		this.sexo = sexo;
	}
	
	public void setDni() {
		
	}

	public String imprime() {
		
		return "Eres " + nombre + " . Y su dni es " + dni;
	}
}
